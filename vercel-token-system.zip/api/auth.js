import jwt from "jsonwebtoken";

export default function handler(req, res) {
  if (req.method === "POST") {
    const { username, password } = req.body;

    if (username === "vcam" && password === "1234") {
      const token = jwt.sign({ username }, process.env.JWT_SECRET, { expiresIn: "1h" });
      return res.status(200).json({ token });
    } else {
      return res.status(401).json({ message: "Invalid credentials" });
    }
  }
  return res.status(405).json({ message: "Method not allowed" });
}
